﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Exceptions
{
    class Class1
    {
    }
}
