﻿using System.Collections.Generic;

namespace $safeprojectname$.UserCases.Customer.GetCustomerList
{
    public class CustomerListViewModel
    {
        public List<CustomerDetailModel> Customers { get; set; }
    }
}