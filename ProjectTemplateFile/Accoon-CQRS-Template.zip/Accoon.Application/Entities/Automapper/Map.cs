﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Entities.Automapper
{
    public sealed class Map
    {
        public Type Source { get; set; }
        public Type Destination { get; set; }
    }
}
